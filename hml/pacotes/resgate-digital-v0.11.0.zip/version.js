window.ResgateDigitalVersion = {
  "version": "0.11.0",
  "stage": 11,
  "responsible": "Davi Marcondes Paes de Souza",
  "role": "Plataforma e Release",
  "change": "Exportação local de resumo da sessão e metadados completos de build reproduzível.",
  "levels": 5,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "45fe0f4f3f05276c8bb4850e5c168dfe14c8c34e",
  "versionCommit": "44f33d5cae4aa3bb314a5c0bfe1d791c092d3b26",
  "buildDate": "2026-10-10T03:22:05.000Z",
  "buildVersion": "0.11.0+ci.45fe0f4f3f05",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
