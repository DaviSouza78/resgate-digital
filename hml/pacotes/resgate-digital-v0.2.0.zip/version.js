window.ResgateDigitalVersion = {
  "version": "0.2.0",
  "stage": 2,
  "responsible": "Miguel Oliveira de Almeida",
  "role": "Desenvolvimento e Qualidade",
  "change": "Execução animada com destaque do comando atual e feedback de colisão.",
  "levels": 1,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "10b3589df2762a82574c078108275a03eb3253c8",
  "versionCommit": "ce389c1a76e58f43b769938c339e7f4c00f7842e",
  "buildDate": "2026-10-10T01:17:26.772Z",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
