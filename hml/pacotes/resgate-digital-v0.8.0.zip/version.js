window.ResgateDigitalVersion = {
  "version": "0.8.0",
  "stage": 8,
  "responsible": "Lucca Castilho costa",
  "role": "SRE e Segurança",
  "change": "Persistência local validada de progresso, aviso de privacidade e botão para apagar dados locais.",
  "levels": 3,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "45fe0f4f3f05276c8bb4850e5c168dfe14c8c34e",
  "versionCommit": "0bb976e295238340c05257b135aa258e6f6ef3aa",
  "buildDate": "2026-10-10T03:22:05.000Z",
  "buildVersion": "0.8.0+ci.45fe0f4f3f05",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
