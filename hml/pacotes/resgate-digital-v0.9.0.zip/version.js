window.ResgateDigitalVersion = {
  "version": "0.9.0",
  "stage": 9,
  "responsible": "Lucas Souza da Silva",
  "role": "Produto e Game Design",
  "change": "Quarto puzzle de depuração, dicas pedagógicas e explicação do aprendizado na tela de vitória.",
  "levels": 4,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "30dda770efc674fc8945cc9d9a0fea7577b5da02",
  "versionCommit": "a1d899bdf75bdd6fc9fc1087a106c200db1ef111",
  "buildDate": "2026-10-10T01:20:33.281Z",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
