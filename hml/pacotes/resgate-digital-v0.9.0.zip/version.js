window.ResgateDigitalVersion = {
  "version": "0.9.0",
  "stage": 9,
  "responsible": "Lucas Souza da Silva",
  "role": "Produto e Game Design",
  "change": "Quarto puzzle de depuração, dicas pedagógicas e explicação do aprendizado na tela de vitória.",
  "levels": 4,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "1e0bd747221428cff25533de6adab1f8449748a2",
  "buildDate": "2026-10-10T00:57:48.729Z",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
