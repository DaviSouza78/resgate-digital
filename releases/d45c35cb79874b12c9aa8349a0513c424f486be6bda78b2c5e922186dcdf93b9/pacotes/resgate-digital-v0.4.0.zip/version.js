window.ResgateDigitalVersion = {
  "version": "0.4.0",
  "stage": 4,
  "responsible": "Lucca Castilho costa",
  "role": "SRE e Segurança",
  "change": "Painel local de integridade do conteúdo; validação de fases e ausência de recursos externos.",
  "levels": 1,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "45fe0f4f3f05276c8bb4850e5c168dfe14c8c34e",
  "versionCommit": "4998c130b98ce5daf25226152499ffc0d9c87a52",
  "buildDate": "2026-10-10T03:22:05.000Z",
  "buildVersion": "0.4.0+ci.45fe0f4f3f05",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
