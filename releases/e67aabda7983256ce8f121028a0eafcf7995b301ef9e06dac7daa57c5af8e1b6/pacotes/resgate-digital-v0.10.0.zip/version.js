window.ResgateDigitalVersion = {
  "version": "0.10.0",
  "stage": 10,
  "responsible": "Miguel Oliveira de Almeida",
  "role": "Desenvolvimento e Qualidade",
  "change": "Comando condicional e quinto puzzle, com testes das duas alternativas da condição.",
  "levels": 5,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "e20b991ad4603b64426ffbd9da53078ef4514833",
  "buildDate": "2026-10-10T00:57:48.729Z",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
