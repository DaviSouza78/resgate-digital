window.ResgateDigitalVersion = {
  "version": "0.7.0",
  "stage": 7,
  "responsible": "Davi Marcondes Paes de Souza",
  "role": "Plataforma e Release",
  "change": "Ficha de release acessível no jogo e manifesto de integridade do pacote.",
  "levels": 3,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "45fe0f4f3f05276c8bb4850e5c168dfe14c8c34e",
  "versionCommit": "7f8a3687db8e8dbe414c2283173aa69ed3463b51",
  "buildDate": "2026-10-10T03:22:05.000Z",
  "buildVersion": "0.7.0+ci.45fe0f4f3f05",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
