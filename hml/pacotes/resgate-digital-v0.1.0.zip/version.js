window.ResgateDigitalVersion = {
  "version": "0.1.0",
  "stage": 1,
  "responsible": "Lucas Souza da Silva",
  "role": "Produto e Game Design",
  "change": "Premissa, público-alvo, primeiro puzzle e instruções de sequência.",
  "levels": 1,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "10b3589df2762a82574c078108275a03eb3253c8",
  "versionCommit": "439c5ab7abf53585f241786d63a665ec2539c0af",
  "buildDate": "2026-10-10T01:17:26.772Z",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
