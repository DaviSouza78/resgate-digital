window.ResgateDigitalVersion = {
  "version": "0.6.0",
  "stage": 6,
  "responsible": "Miguel Oliveira de Almeida",
  "role": "Desenvolvimento e Qualidade",
  "change": "Comando Repetir e terceiro puzzle, com expansão de ações limitada e testada.",
  "levels": 3,
  "sourceHash": "2857067e7787524a078377a05a16d06ae1550f6e676c2803b9fdd71955c3eb5d",
  "commit": "10b3589df2762a82574c078108275a03eb3253c8",
  "versionCommit": "471d2f88200a46b633c45799250e03243fa7c9f2",
  "buildDate": "2026-10-10T01:17:26.772Z",
  "publication": "artefato",
  "authorship": "Responsabilidade designada; implementação e registro preparados com assistência de IA. Revisão humana não presumida."
};
